package com.tls.client.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TlsClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(TlsClientApplication.class, args);
	}

}
