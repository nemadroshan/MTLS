package com.tls.client.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TlsClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
